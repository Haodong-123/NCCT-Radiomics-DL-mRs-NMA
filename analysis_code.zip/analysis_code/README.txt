Analysis code for:

NCCT-Based Radiomics and Deep Learning for mRS Prognostication After
Spontaneous Intracerebral Hemorrhage: A Network Meta-Analysis

Contents
--------
_dh_sens1_nma.R            Headless Bayesian network meta-analysis (diagnostic test
                           accuracy) pipeline used for the sensitivity analysis
                           excluding overlapping cohorts.
_test_dh_yearcont.R        Headless Bayesian meta-regression pipeline for a continuous
                           covariate (e.g., publication year); also used to produce the
                           meta-regression outputs reported in the supplement.
build_sens1_csv.py         Python helper that assembles the input CSV
                           (data/file_sens1.csv).
data/file_sens1.csv        2x2 data used for the sensitivity analysis
                           (columns: s, algo, tp, fp, fn, tn).
data/raw_source_0.90d.csv  Source records used to build file_sens1.csv.
data/file1.csv             Dataset used for the meta-regression runs.

Usage
-----
Rscript _dh_sens1_nma.R <csv> <outdir> <n_iter> <n_burnin> <n_chains> <n_thin> [seed]
Rscript _test_dh_yearcont.R <csv> <outdir> <n_iter> <n_burnin> <n_chains> <n_thin> [covariates|ALL] [seed]

Environment
-----------
R 4.3.2; JAGS 4.3.1. The scripts were executed in the authors' analysis
environment, which provides the shared functions (data processing, model
fitting, and summary routines) referenced by these pipelines.

Notes
-----
No primary patient data are included; all inputs are aggregate, study-level
data extracted from published studies.
