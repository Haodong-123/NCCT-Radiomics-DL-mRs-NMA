# -*- coding: utf-8 -*-
"""Build sensitivity dataset from the user-provided raw CSV:
   - drop Huang et al., 2022 (s=9) entirely (companion report of same cohort)
   - Liu et al., 2026: keep only G2 cohort (s=11, n=35); drop s=12 (G3) and s=13 (G4)
   Result: 36 rows, 13 study units."""
import csv, os, shutil

src = r"C:\Users\82702\.openclaw\media\inbound\0.90天数据_2---fff3e7e9-2643-4acc-be6c-a4ac2b34f5ff.csv"
dst_dir = r"C:\Users\82702\.openclaw\workspace\DH_work\sens1_in"
os.makedirs(dst_dir, exist_ok=True)

# keep a source copy
shutil.copyfile(src, os.path.join(dst_dir, "raw_source_0.90d.csv"))

dst = os.path.join(dst_dir, "file_sens1.csv")
rows = list(csv.DictReader(open(src, encoding="utf-8-sig")))
keep = []
for r in rows:
    if r["study"].strip() == "Huang et al., 2022":
        continue
    if r["study"].strip() == "Liu et al., 2026" and r["s"].strip() in ("12", "13"):
        continue
    keep.append(r)

fn = list(rows[0].keys())
with open(dst, "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=fn)
    w.writeheader()
    w.writerows(keep)

print("kept rows:", len(keep), "->", dst)
ss = sorted(set(r["s"] for r in keep), key=int)
print("s values kept:", ss, "| n units:", len(ss))
from collections import Counter
print("rows per algo:", dict(Counter(r["algo"] for r in keep)))
for r in keep:
    if r["study"].strip().startswith("Liu"):
        print("  Liu kept:", r["s"], r["algo"], r["tp"], r["fp"], r["fn"], r["tn"])
for r in keep:
    if r["study"].strip().startswith("Huang"):
        print("  Huang kept:", r["study"], r["s"], r["algo"])
