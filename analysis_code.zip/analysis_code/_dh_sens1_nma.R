# Headless run: MAIN diagnostic NMA (same pipeline as app) for sensitivity dataset.
# Usage:
#   Rscript _dh_sens1_nma.R <csv> <outdir> <n_iter> <n_burnin> <n_chains> <n_thin> [seed]
# Outputs: sens1_results.csv (node x Se/Sp/DOR: rank, SUCRA%, estimate + 95% CrI),
#          sens1_bugs_summary.csv (full posterior summary), sens1_full.rds
.libPaths(c("C:/Users/82702/Desktop/Claude code/dta_nma_app/.r-lib", .libPaths()))
args <- commandArgs(trailingOnly = TRUE)
csv_path <- args[1]; outdir <- args[2]
n_iter <- as.integer(args[3]); n_burnin <- as.integer(args[4])
n_chains <- as.integer(args[5]); n_thin <- as.integer(args[6])
seed <- if (length(args) >= 7 && nzchar(args[7])) as.integer(args[7]) else 2026L
tag <- gsub("[^A-Za-z0-9_.-]", "_", basename(csv_path))
res_dir <- file.path(outdir, tag)
dir.create(res_dir, recursive = TRUE, showWarnings = FALSE)
msg <- function(...) cat(sprintf(...), "\n")
msg("[meta] tag=%s iter=%d burn=%d chains=%d thin=%d seed=%d", tag, n_iter, n_burnin, n_chains, n_thin, seed)

suppressPackageStartupMessages(source("global.R", encoding = "UTF-8", local = FALSE))

raw <- read.csv(csv_path, stringsAsFactors = FALSE, fileEncoding = "UTF-8")
needed <- c("s", "algo", "tp", "fp", "fn", "tn")
miss <- needed[!needed %in% names(raw)]
stopifnot(length(miss) == 0L)
for (col in c("tp", "fp", "fn", "tn")) raw[[col]] <- suppressWarnings(as.numeric(raw[[col]]))
stopifnot(!any(is.na(raw[, c("tp", "fp", "fn", "tn")])))
pos <- raw$tp + raw$fn; neg <- raw$fp + raw$tn
stopifnot(all(pos > 0), all(neg > 0))

pres <- sort(unique(as.character(raw$algo)))
def5 <- c("Conventional clinical-CT models",
          "CT-based radiomics-only ML models",
          "Clinical-CT-radiomics ML models",
          "CT-based DL-only models",
          "Clinical-CT-DL fusion models")
algo_disp <- vapply(pres, function(p) {
  j <- match(p, LETTERS[seq_len(length(def5))])
  if (!is.na(j)) def5[j] else p
}, character(1))
pd <- process_data(raw, algo_disp)
msg("[meta] studies=%d algos=%d rows=%d", pd$ns, pd$nalgo, nrow(pd$data))

t0 <- Sys.time()
out <- run_dta_main_nma_job(pd, n_iter = n_iter, n_burnin = n_burnin,
                            n_chains = n_chains, n_thin = n_thin, seed = seed)
el <- as.numeric(Sys.time() - t0, units = "secs")
cv <- out$fit$convergence
msg("[run] elapsed=%.0fs converged=%s rhat_max=%.4f neff_min=%.0f", el, cv$converged, cv$rhat_max, cv$neff_min)

sims <- out$sims
nf <- pd$names_flat
res_list <- list()
for (met in c("Se", "Sp", "DOR")) {
  s <- .dta_sucra_vec(sims, pd, metric = met)
  rk <- integer(length(s)); o <- order(-as.numeric(s)); rk[o] <- seq_along(o)
  mat <- sims[[met]]
  mat <- if (is.matrix(mat)) mat else matrix(mat, ncol = 1L)
  res_list[[met]] <- data.frame(
    node = nf, metric = met, rank = rk,
    sucra_pct = round(100 * as.numeric(s), 1),
    est = round(apply(mat, 2, mean), 2),
    lo = round(apply(mat, 2, quantile, 0.025), 2),
    hi = round(apply(mat, 2, quantile, 0.975), 2),
    stringsAsFactors = FALSE, check.names = FALSE
  )
}
res <- do.call(rbind, res_list)
write.csv(res, file.path(res_dir, "sens1_results.csv"), row.names = FALSE, fileEncoding = "UTF-8")
for (i in seq_len(nrow(res))) {
  msg("[res] %-42s %-4s rank=%d sucra=%.1f%% est=%.2f (%.2f, %.2f)",
      res$node[i], res$metric[i], res$rank[i], res$sucra_pct[i], res$est[i], res$lo[i], res$hi[i])
}
write.csv(out$fit$BUGSoutput$summary, file.path(res_dir, "sens1_bugs_summary.csv"), fileEncoding = "UTF-8")
saveRDS(list(results = res, convergence = cv, tau_logDOR = out$tau_logDOR), file.path(res_dir, "sens1_full.rds"))
msg("[done] %s", res_dir)
