# Headless end-to-end test: DTA-NMA Bayesian meta-regression on real DH data.
# Replicates app pipeline: upload validation -> process_data -> run_metareg (auto type)
# -> main table / docx / tau2 / bubble (cont) / subgroup forest (cat) exports.
# Usage:
#   Rscript _test_dh_metareg.R <csv> <outdir> <n_iter> <n_burnin> <n_chains> <n_thin> [cov1,cov2,...|ALL] [seed]
# All console output ASCII-only (Windows GBK console safety).

.libPaths(c("C:/Users/82702/Desktop/Claude code/dta_nma_app/.r-lib", .libPaths()))
args <- commandArgs(trailingOnly = TRUE)
csv_path  <- args[1]
outdir    <- args[2]
n_iter    <- as.integer(args[3]); n_burnin <- as.integer(args[4])
n_chains  <- as.integer(args[5]); n_thin   <- as.integer(args[6])
cov_arg   <- if (length(args) >= 7 && nzchar(args[7])) args[7] else "ALL"
seed      <- if (length(args) >= 8 && nzchar(args[8])) as.integer(args[8]) else 2026L
tag       <- gsub("[^A-Za-z0-9_.-]", "_", basename(csv_path))
res_dir   <- file.path(outdir, tag)
dir.create(res_dir, recursive = TRUE, showWarnings = FALSE)

msg <- function(...) cat(sprintf(...), "\n")
msg("[meta] tag=%s iter=%d burn=%d chains=%d thin=%d covs=%s seed=%d",
    tag, n_iter, n_burnin, n_chains, n_thin, cov_arg, seed)

suppressPackageStartupMessages(source("global.R", encoding = "UTF-8", local = FALSE))

# ---- app upload validation (mirrors app.R observeEvent input$file) ----
raw <- read.csv(csv_path, stringsAsFactors = FALSE, fileEncoding = "UTF-8")
needed <- c("s", "algo", "tp", "fp", "fn", "tn")
miss <- needed[!needed %in% names(raw)]
stopifnot(length(miss) == 0L)
for (col in c("tp", "fp", "fn", "tn")) raw[[col]] <- suppressWarnings(as.numeric(raw[[col]]))
stopifnot(!any(is.na(raw[, c("tp", "fp", "fn", "tn")])))
stopifnot(!any(raw[, c("tp", "fp", "fn", "tn")] < 0, na.rm = TRUE))
pos <- raw$tp + raw$fn; neg <- raw$fp + raw$tn
stopifnot(all(pos > 0), all(neg > 0), all(raw$tp <= pos), all(raw$tn <= neg))
# 算法显示名：与 app 一致，LETTERS A–E 映射为正式名（含前缀），其余原样
pres <- sort(unique(as.character(raw$algo)))
def5 <- c("Conventional clinical-CT models",
          "CT-based radiomics-only ML models",
          "Clinical-CT-radiomics ML models",
          "CT-based DL-only models",
          "Clinical-CT-DL fusion models")
algo_disp <- vapply(pres, function(p) {
  j <- match(p, LETTERS[seq_len(length(def5))])
  if (!is.na(j)) def5[j] else p
}, character(1))
pd <- process_data(raw, algo_disp)
msg("[meta] studies=%d algos=%d rows=%d", pd$ns, pd$nalgo, nrow(pd$data))

# ---- covariate inventory + auto type (mirror run_metareg is_cont rule) ----
exclude <- c("s", "algo", "tp", "fp", "fn", "tn", "pos", "neg")
cov_cols <- setdiff(names(pd$data), exclude)
classify <- function(x) {
  if (is.numeric(x) && length(unique(stats::na.omit(x))) > 8) "continuous" else "categorical"
}
inv <- data.frame(
  Column = cov_cols,
  Type   = vapply(cov_cols, function(c) classify(pd$data[[c]]), character(1)),
  NAs    = vapply(cov_cols, function(c) sum(is.na(pd$data[[c]])), integer(1)),
  Unique = vapply(cov_cols, function(c) length(unique(stats::na.omit(pd$data[[c]]))), integer(1)),
  stringsAsFactors = FALSE, row.names = NULL
)
write.csv(inv, file.path(res_dir, "00_covariate_inventory.csv"), row.names = FALSE)
for (i in seq_len(nrow(inv))) {
  msg("[cov] %-22s type=%-11s NA=%d unique=%d", inv$Column[i], inv$Type[i], inv$NAs[i], inv$Unique[i])
}

sel <- if (cov_arg == "ALL") cov_cols else trimws(strsplit(cov_arg, ",", fixed = TRUE)[[1]])
sel <- sel[sel %in% cov_cols]
msg("[meta] will run %d covariate(s): %s", length(sel), paste(sel, collapse = ", "))

cached_null <- NULL; cached_key <- NULL
for (cv in sel) {
  t0 <- Sys.time()
  msg("[run] === %s (auto) ===", cv)
  fit <- null_obj <- NULL
  err <- tryCatch({
    need_key <- if (!is.null(cached_null)) {
      if (exists(".dta_mr_null_key", mode = "function")) {
        .dta_mr_null_key(pd, cv, n_iter, n_burnin, n_chains, n_thin, seed)
      } else NA_character_
    } else NA_character_
    reuse <- !is.null(cached_null) && !is.na(need_key) && identical(need_key, cached_key)
    fit <- run_metareg(pd, cov_col = cv,
                       n_iter = n_iter, n_burnin = n_burnin,
                       n_chains = n_chains, n_thin = n_thin,
                       seed = seed, cov_type = "continuous",
                       fit_null = !reuse, null_fit = if (reuse) cached_null else NULL)
    NULL
  }, error = function(e) conditionMessage(e))
  if (!is.null(err)) {
    msg("[FAIL] %s : %s", cv, substr(err, 1, 400))
    writeLines(err, file.path(res_dir, sprintf("FAIL_%s.txt", gsub("[^A-Za-z0-9_.-]", "_", cv))))
    next
  }
  ct <- attr(fit, "cov_type"); lvl <- attr(fit, "cov_levels"); ndrop <- attr(fit, "mr_na_dropped") %||% 0L
  msg("[ok] %s type=%s levels=%s dropped=%d elapsed=%.0fs",
      cv, ct, paste(lvl, collapse = "/"), ndrop, as.numeric(Sys.time() - t0, units = "secs"))
  null_obj <- attr(fit, "mr_null")
  if (!is.null(null_obj)) {
    cached_null <- null_obj
    cached_key <- if (exists(".dta_mr_null_key", mode = "function")) {
      .dta_mr_null_key(pd, cv, n_iter, n_burnin, n_chains, n_thin, seed)
    } else "plain"
  }
  # clean stem per covariate
  stem <- gsub("[^A-Za-z0-9_.-]", "_", cv)

  # ---- summary table + csv (main three-line table content) ----
  tbl <- tryCatch(make_dta_metareg_table(fit, pd, cv), error = function(e) NULL)
  if (is.null(tbl)) {
    msg("[WARN] %s make_dta_metareg_table failed", cv)
  } else {
    write.csv(tbl, file.path(res_dir, sprintf("%s_main_table.csv", stem)), row.names = FALSE, fileEncoding = "UTF-8")
    for (j in seq_len(nrow(tbl))) {
      msg("[tbl] %-16s %-12s rows=%s Se=%s pSe=%s Sp=%s pSp=%s DOR=%s pDOR=%s",
          tbl$Covariates[j], tbl$Categories[j], tbl$`Rows (n)`[j],
          tbl$`logit(Sensitivity) β (95% CrI)`[j], tbl$`Bayesian P (Se)`[j],
          tbl$`logit(Specificity) β (95% CrI)`[j], tbl$`Bayesian P (Sp)`[j],
          tbl$`log(DOR) β (95% CrI)`[j], tbl$`Bayesian P (DOR)`[j])
    }
  }

  # ---- Word docx (main + tau2 second table) ----
  docx_file <- file.path(res_dir, sprintf("MetaReg_Table_%s_%s.docx", stem, format(Sys.Date(), "%Y-%m-%d")))
  docx_ok <- tryCatch({
    write_dta_metareg_docx(docx_file, fit, pd, cv, mr_null = null_obj)
    file.exists(docx_file) && file.info(docx_file)$size > 500L
  }, error = function(e) { msg("[FAIL] docx %s : %s", cv, substr(conditionMessage(e), 1, 300)); FALSE })
  msg("[exp] %s docx=%s", cv, if (docx_ok) "OK" else "FAIL")

  # ---- tau2 df ----
  if (!is.null(null_obj)) {
    td <- tryCatch(.dta_mr_tau2_df(fit, null_obj), error = function(e) NULL)
    if (!is.null(td)) {
      write.csv(td, file.path(res_dir, sprintf("%s_tau2.csv", stem)), row.names = FALSE, fileEncoding = "UTF-8")
      td_ascii <- td
      names(td_ascii) <- c("Metric", "tau2_null", "tau2_cov", "R2")
      for (j in seq_len(nrow(td_ascii))) msg("[tau] %s", paste(td_ascii[j, ], collapse = " | "))
    }
  }

  # ---- derived DOR ----
  dd <- tryCatch(.dta_mr_dor_derived(fit), error = function(e) NULL)
  if (!is.null(dd)) {
    write.csv(dd, file.path(res_dir, sprintf("%s_dor_derived.csv", stem)), row.names = FALSE, fileEncoding = "UTF-8")
    for (j in seq_len(nrow(dd))) {
      msg("[dor] %-12s bSe=%s bSp=%s bDOR=%s ROR=%s Pr>1=%.3f", dd$Level[j],
          .dta_mr_fmt_beta(unlist(dd[j, c("beta_Se", "beta_Se_lo", "beta_Se_hi")])),
          "", "", "", dd$Pr_ROR_gt1[j])
    }
  }

  # ---- figures ----
  if (identical(ct, "continuous")) {
    bd <- tryCatch(.dta_mr_bubble_all(fit, pd, cv), error = function(e) NULL)
    if (is.null(bd)) {
      msg("[WARN] %s bubble data NULL", cv)
    } else {
      p  <- plot_metareg_bubble(bd$point_df, bd$line_df, bd$cov_label, bd$cols, bd$stat_df)
      pe <- .strip_chinese(p)
      pdf_f <- file.path(res_dir, sprintf("MetaReg_Bubble_%s_%s.pdf", stem, Sys.Date()))
      grDevices::cairo_pdf(pdf_f, width = 8, height = 9, bg = "white", family = "Times New Roman")
      print(pe); grDevices::dev.off()
      tif_f <- file.path(res_dir, sprintf("MetaReg_Bubble_%s_%s.tiff", stem, Sys.Date()))
      grDevices::tiff(tif_f, width = 8, height = 9, units = "in", res = 600,
                      compression = "lzw", type = "cairo", family = "Times New Roman")
      print(pe); grDevices::dev.off()
      png_f <- file.path(res_dir, sprintf("%s_bubble_preview.png", stem))
      grDevices::png(png_f, width = 800, height = 900, res = 110, type = "cairo")
      print(p); grDevices::dev.off()
      msg("[exp] %s bubble pdf=%s tiff=%s png=%s",
          cv, file.exists(pdf_f) && file.info(pdf_f)$size > 500L,
          file.exists(tif_f) && file.info(tif_f)$size > 500L,
          file.exists(png_f) && file.info(png_f)$size > 500L)
    }
  } else {
    p  <- plot_subgroup_forest_metareg(fit, pd, col_levels = NULL, journal_style = "default")
    pe <- .strip_chinese(p)
    pdf_f <- file.path(res_dir, sprintf("MetaReg_Subgroup_Forest_%s_%s.pdf", stem, Sys.Date()))
    grDevices::cairo_pdf(pdf_f, width = 10, height = 6, bg = "white", family = "Times New Roman")
    print(pe); grDevices::dev.off()
    tif_f <- file.path(res_dir, sprintf("MetaReg_Subgroup_Forest_%s_%s.tiff", stem, Sys.Date()))
    grDevices::tiff(tif_f, width = 10, height = 6, units = "in", res = 600,
                    compression = "lzw", type = "cairo", family = "Times New Roman")
    print(pe); grDevices::dev.off()
    png_f <- file.path(res_dir, sprintf("%s_subgroup_preview.png", stem))
    grDevices::png(png_f, width = 1000, height = 600, res = 110, type = "cairo")
    print(p); grDevices::dev.off()
    msg("[exp] %s subgroup pdf=%s tiff=%s png=%s",
        cv, file.exists(pdf_f) && file.info(pdf_f)$size > 500L,
        file.exists(tif_f) && file.info(tif_f)$size > 500L,
        file.exists(png_f) && file.info(png_f)$size > 500L)
  }
  gc(verbose = FALSE)
}
msg("[meta] DONE tag=%s", tag)
